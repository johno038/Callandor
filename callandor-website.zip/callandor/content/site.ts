/* ══════════════════════════════════════════════════════════════════
   CALLANDOR : SITE CONTENT
   ------------------------------------------------------------------
   This is the single source of truth for all editable copy on the
   website. Everything a non-developer might want to change lives here.

   Edit the text below and the site updates. Structure is typed so that
   mistakes surface at build time. Nothing here is classified and no
   customer names are used.

   TESTIMONIAL & RECOGNITION CONTENT
   The evidence quotes are reproduced as supplied and approved.
   Do not alter wording, attribution or the anonymity notes without
   fresh sign-off. See LAUNCH_CHECKLIST.md.
   ══════════════════════════════════════════════════════════════════ */

export const company = {
  name: "Callandor",
  tagline: "Enabling Trusted Technology",
  email: "hello@callandor.io",
  linkedin: "https://www.linkedin.com/company/callandor/",
  companyNumber: "00000000", // TODO: confirm Companies House number
  url: "https://www.callandor.io", // inferred from email domain — TODO: confirm production domain
} as const;

export const nav = {
  links: [
    { label: "Evidence", href: "#evidence" },
    { label: "Capabilities", href: "#capabilities" },
    { label: "Why Callandor", href: "#why" },
    { label: "How We Work", href: "#how-we-work" },
    { label: "Use Cases", href: "#use-cases" },
    { label: "Founders", href: "#founders" },
  ],
  cta: { label: "Start a Conversation", href: "#contact" },
} as const;

export const hero = {
  headline: "Engineering confidence into complex technology.",
  supporting:
    "Callandor helps organisations assure, govern and introduce complex technology in environments where trust, evidence and operational outcomes matter.",
  primaryCta: { label: "Start a Conversation", href: "#contact" },
  secondaryCta: { label: "Explore Our Approach", href: "#how-we-work" },
} as const;

export const evidence = {
  eyebrow: "Evidence",
  title: "Trusted where it counts.",
  intro:
    "Our work is judged by outcomes. Technology approved, governance in place, and confidence earned across the organisations that rely on it.",
  // Four proof points.
  strip: [
    "Independent Assurance",
    "Approval Delivery",
    "Cross-Domain Expertise",
    "Operational Experience",
  ],
  // Featured evidence cards.
  cards: {
    testimonial: {
      kind: "Customer Testimonial",
      quote:
        "Matt was incredibly helpful and went above and beyond to help us achieve an important accreditation for my organisation in a very short timescale. Matt contacted multiple different stakeholders throughout the organisation to gain their trust and buy-in before the accreditation decision was made. This allowed my organisation to take part in an important strategic exercise showcasing best-of-breed technology for Cross Domain Solutions. I would highly recommend Matt's services.",
      attributionName: "Senior Technology Leader",
      attributionOrg: "Defence Supplier",
      note: "Published anonymously at the customer's request.",
    },
    recognition: {
      kind: "Formal Recognition",
      quote:
        "The longer I spend thinking about how we must fight, the more certain I become that this project is fundamental to our future.",
      secondaryQuote: "We couldn't have done it without your team.",
      attributionName: "Brigadier",
      attributionOrg: "UK Defence",
      caption:
        "Extracted from a formal letter recognising assurance support provided during Exercise RHINO BIZZ.",
    },
  },
} as const;

export const capabilities = {
  eyebrow: "Capabilities",
  title: "What we do.",
  intro:
    "We bring structure to complicated programmes, producing the evidence, governance and confidence that technology needs to become operational.",
  items: [
    {
      icon: "assurance",
      title: "Technology Assurance",
      description:
        "Independent, evidence-led assurance that gives decision makers a clear, defensible basis for trusting new technology.",
    },
    {
      icon: "approval",
      title: "Approval Delivery",
      description:
        "We navigate complex approval environments and assemble the evidence and governance needed to reach an operational decision.",
    },
    {
      icon: "governance",
      title: "Governance",
      description:
        "Clear ownership, structure and accountability across suppliers, technical teams and decision makers, from concept to service.",
    },
    {
      icon: "trusted-ai",
      title: "Trusted AI",
      description:
        "Governance and assurance for AI adoption, so organisations can introduce artificial intelligence responsibly and with confidence.",
    },
  ],
} as const;

export const expertise = {
  eyebrow: "Experience",
  title: "Where our experience sits.",
  intro:
    "Callandor helps organisations navigate technology assurance, governance and approval challenges, and produce the confidence needed for technology to become operational.",
  areas: [
    "Technology Assurance",
    "Approval Delivery",
    "Governance",
    "Requirements Management",
    "Cross Domain Solutions",
    "Operational Technology",
    "Secure Information Sharing",
    "AI Governance",
    "Trusted AI Adoption",
  ],
  // What Callandor is NOT, stated plainly, with restraint.
  positioning: {
    lead: "We are delivery specialists who understand assurance.",
    not: [
      "Not an accreditation body",
      "Not auditors",
      "Not management consultants",
    ],
  },
} as const;

export const why = {
  eyebrow: "Why Callandor",
  title: "Technology succeeds when people trust it.",
  intro:
    "Technology rarely fails because of engineering alone. Programmes stall when the conditions for trust are missing, and that is where we focus.",
  // Four common failure points.
  problems: [
    {
      title: "Unclear governance",
      description:
        "Decisions slow when ownership and accountability are ambiguous. We establish structure that holds under pressure.",
    },
    {
      title: "Missing evidence",
      description:
        "Approval depends on evidence. We identify what is needed early and produce it to a standard that stands up to scrutiny.",
    },
    {
      title: "Fragmented ownership",
      description:
        "Multiple suppliers and teams can pull in different directions. We bring them together behind a shared route forward.",
    },
    {
      title: "Late assurance",
      description:
        "Assurance left to the end becomes a bottleneck. We build it in from the start so it enables delivery rather than blocking it.",
    },
  ],
  closing:
    "Callandor resolves these problems, so that good technology reaches the people who need it.",
} as const;

export const howWeWork = {
  eyebrow: "How We Work",
  title: "A clear route from uncertainty to trusted use.",
  intro:
    "A structured approach that brings order to complex programmes and keeps every stage focused on the operational outcome.",
  steps: [
    {
      icon: "review",
      title: "Review",
      description:
        "We understand the technology, the environment and the decision that needs to be made, and where the real risks and gaps sit.",
    },
    {
      icon: "plan",
      title: "Plan",
      description:
        "We define the evidence, governance and stakeholder path required, and set a realistic route to approval.",
    },
    {
      icon: "deliver",
      title: "Deliver",
      description:
        "We do the work, producing evidence, coordinating suppliers and driving activity to keep the programme moving.",
    },
    {
      icon: "assure",
      title: "Assure",
      description:
        "We bring the evidence together into a clear, defensible case that decision makers can trust.",
    },
    {
      icon: "enable",
      title: "Enable",
      description:
        "Technology reaches trusted operational use, and the organisation is left more capable of doing it again.",
    },
  ],
} as const;

export const useCases = {
  eyebrow: "Use Cases",
  title: "Representative work.",
  intro:
    "Illustrative of the challenges we solve. No classified information and no customer names.",
  // Four representative examples.
  items: [
    {
      icon: "rapid",
      title: "Rapid Approval Delivery",
      description:
        "Securing an important approval to a demanding timescale by coordinating stakeholders and assembling evidence in parallel.",
    },
    {
      icon: "cross-domain",
      title: "Cross Domain Technology",
      description:
        "Supporting the assurance and governance of technology that must move information safely between security domains.",
    },
    {
      icon: "multi-supplier",
      title: "Multi Supplier Governance",
      description:
        "Bringing clear ownership and structure to programmes involving several suppliers and technical teams.",
    },
    {
      icon: "responsible-ai",
      title: "Responsible AI",
      description:
        "Establishing the governance and evidence needed to adopt AI responsibly and with confidence.",
    },
  ],
} as const;

export const founders = {
  eyebrow: "Founders",
  title: "Led by people who have done the work.",
  intro:
    "Callandor is founded by practitioners who combine operational perspective with technical depth.",
  people: [
    {
      name: "Matt Johnston",
      role: "Co-Founder",
      // Photo placeholder. Drop a square image at /public/founders/matt-johnston.jpg
      photo: "/founders/matt-johnston.jpg",
      initials: "MJ",
      bio: [
        "Matt is an experienced technology assurance, governance and requirements specialist with a strong track record of helping complex systems move from uncertainty towards trusted operational use.",
        "Drawing on experience from both the British Army and the defence technology sector, Matt brings an operational perspective to assurance. He understands that evidence, governance and approval activity must ultimately support real people, real decisions and real operational outcomes.",
        "He specialises in navigating high-pressure approval environments where technical delivery, operational need, risk, evidence and stakeholder confidence must come together.",
        "Matt is particularly effective at bringing structure to complex situations, building trust across multiple organisations and translating technical or governance challenges into a clear route forward. He combines strategic judgement with hands-on delivery, and stays focused on the outcome rather than allowing assurance to become an exercise in paperwork.",
      ],
      focus: [
        "Technology Assurance",
        "Approval Strategy",
        "Governance",
        "Requirements Management",
        "Cross Domain Solutions",
        "Stakeholder Engagement",
        "Evidence Development",
        "Operational Delivery",
        "Trusted Technology",
      ],
    },
    {
      name: "Dr Joshua Hilton",
      role: "Co-Founder",
      photo: "/founders/josh-hilton.jpg",
      initials: "JH",
      bio: [
        "Josh is an experienced consultant and operational researcher with more than seven years of experience delivering analysis, technical insight and data-backed strategy across complex environments, particularly within the defence sector.",
        "A PhD nuclear physicist, data scientist, aerospace engineer and software developer, he brings a rare combination of scientific depth, analytical rigour and practical delivery experience. His work spans large datasets, simulations, machine learning, operational research and advanced software engineering.",
        "Josh is particularly strong at extracting meaningful insight from difficult or imperfect data and transforming that insight into practical, defensible recommendations.",
        "His multidisciplinary background allows him to solve problems from perspectives that traditional engineering teams often overlook.",
      ],
      focus: [
        "Data Science",
        "Operational Research",
        "Machine Learning",
        "Simulation",
        "Nuclear Physics",
        "Software Engineering",
        "Artificial Intelligence",
        "Technical Strategy",
        "Python",
        "C#",
        "SQL",
        "Java",
        "C++",
      ],
    },
  ],
} as const;

export const clients = {
  eyebrow: "Who We Work With",
  title: "One capability, many applications.",
  intro:
    "Callandor's work spans sectors where trust, evidence and operational outcomes are non-negotiable. Defence is one application of the capability, not the whole of it.",
  primary: ["Defence", "Government", "National Security"],
  secondary: [
    "Critical National Infrastructure",
    "Regulated Industry",
    "Engineering",
    "Aerospace",
    "AI Companies",
    "Technology Suppliers",
  ],
} as const;

export const contact = {
  eyebrow: "Contact",
  title: "Let's build something trusted.",
  intro:
    "Whether you're introducing a new technology, navigating a complex approval process or looking for an experienced assurance partner, we'd welcome a conversation.",
  formEndpoint: "", // Optional: set to a form handler URL (Formspree, etc.). Empty uses the mailto fallback.
} as const;

export const footer = {
  tagline: "Enabling Trusted Technology",
  legalLinks: [
    { label: "Privacy", href: "/privacy" },
    { label: "Terms", href: "/terms" },
  ],
} as const;

export const seo = {
  title: "Callandor | Enabling Trusted Technology",
  description:
    "Callandor helps organisations assure, govern and introduce complex technology in environments where trust, evidence and operational outcomes matter.",
  keywords: [
    "technology assurance",
    "approval delivery",
    "governance",
    "cross domain solutions",
    "trusted AI",
    "AI governance",
    "requirements management",
    "defence technology assurance",
  ],
} as const;
