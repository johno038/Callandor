# Callandor — Launch Checklist

Everything below should be confirmed before the site goes live. Items are
grouped by priority. Nothing here is classified, and no customer names are
used anywhere on the site.

---

## 1 · Content requiring final approval (do not launch without)

### Contact & legal placeholders — in `content/site.ts` (`company`)

- [x] **Email** — `hello@callandor.io` _(confirmed)_
- [x] **LinkedIn URL** — `https://www.linkedin.com/company/callandor/` _(confirmed)_
- [ ] **Companies House number** — currently `00000000` _(placeholder)_
- [ ] **Production domain** — currently `https://www.callandor.io`, _inferred from the
      email domain — please confirm._ Used for canonical URL, sitemap and social tags.

### Testimonial & recognition content — legal / permission

- [ ] **Customer testimonial (Card 1).** Reproduced as supplied and published
      **anonymously at the customer's request** ("Senior Technology Leader,
      Defence Supplier"). Confirmed the source is content for the *anonymised*
      version. **Do not** attach a name or organisation without written sign-off
      from the customer's legal team.
- [ ] **Formal recognition (Card 2).** Two short quotations extracted from a
      formal letter of thanks, attributed to "Brigadier, UK Defence", with the
      caption referencing Exercise RHINO BIZZ. The quotations currently used are:
      _"The longer I spend thinking about how we must fight, the more certain I
      become that this project is fundamental to our future."_ and _"We couldn't
      have done it without your team."_ The internal project name has been
      redacted (shown as "this project"). Confirm the programme name and
      quotations may be published. The letter itself is **not** reproduced, and
      **no** signature, address, email or MOD insignia is shown.
- [ ] Confirm neither card implies **Ministry of Defence or British Army
      endorsement** of Callandor. (Current wording recognises support provided;
      it does not claim endorsement — keep it that way.)

### Founder details

- [ ] Matt Johnston bio — approved by Matt.
- [ ] Dr Joshua Hilton bio — approved by Josh.
- [ ] Founder photos supplied (square, ≥800px) — or launch with monograms.

---

## 2 · Brand & legal safeguards (verify present)

- [x] No protected logos reproduced (no MOD / British Army insignia).
- [x] No signatures, postal addresses or personal emails displayed.
- [x] The supplied letter of thanks is **not** reproduced — only approved
      short quotations are used.
- [x] Testimonial wording used exactly as supplied.
- [x] No classified information; no real customer names.
- [x] No banned marketing language ("cutting edge", "world leading",
      "revolutionary", "best in class", "disruptive", "mission critical").
- [x] Copy is British English throughout.
- [ ] **Privacy Policy** — replace placeholder at `/privacy` with the finalised
      policy (must cover contact-form data). _Legal review required._
- [ ] **Terms of Use** — replace placeholder at `/terms`. _Legal review required._
- [ ] Cookie/analytics notice — only needed if analytics are added (none by
      default).

---

## 3 · Functional

- [ ] Run `npm install && npm run build` — confirm a clean production build.
- [ ] Contact form: decide between the **mailto fallback** (default) or a form
      endpoint (`contact.formEndpoint`). Test a real submission end-to-end.
- [ ] Check all navigation anchors scroll to the right sections.
- [ ] Test on real devices: mobile (portrait), tablet, desktop, and a very wide
      display.
- [ ] Test with **reduced motion** enabled (macOS/iOS: Reduce Motion) — the site
      should be fully usable and static.
- [ ] Keyboard-only pass: tab order, visible focus, skip link works.
- [ ] Lighthouse: aim for 95+ on Performance, Accessibility, Best Practices, SEO.

---

## 4 · Assets & polish

- [ ] Founder photography (or confirm monograms for launch).
- [ ] Replace `public/og-image.svg` with a rendered PNG if any target platform
      doesn't preview SVG social cards well (LinkedIn/Twitter generally prefer
      PNG/JPG at 1200×630).
- [ ] Favicon renders correctly across browsers (an `.ico` can be added
      alongside `favicon.svg` for older browsers if desired).

---

## 5 · SEO & discoverability

- [ ] Confirm `company.url` is the live domain (drives canonical + sitemap).
- [ ] Submit `sitemap.xml` to Google Search Console once live.
- [ ] Confirm meta title/description read well in a search-result preview.
- [ ] Set up a LinkedIn company page and link it (`company.linkedin`).

---

## Notes

The site is deliberately restrained: defence is presented as **one application**
of the capability, not the whole business. Keep that balance if adding content —
lead with the capability, not the sector.
