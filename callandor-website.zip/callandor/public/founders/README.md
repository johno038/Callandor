# Founder photos

`matt-johnston.jpg` and `josh-hilton.jpg` are in place. They have been given a
matched treatment (a cohesive cool monochrome on one uniform dark background) so
the two portraits read as a consistent set on the dark theme.

To replace either, drop in a new **square** image (ideally 800×800, `.jpg` or
`.webp`) using the same filename. If a file is ever missing, the site falls back
to an elegant monogram automatically, so the page never breaks.

Filenames are referenced in `content/site.ts`.
