/**
 * Lightweight className joiner.
 * Filters out falsy values and joins the rest with a space.
 * Kept dependency-free to avoid adding clsx/tailwind-merge for a small site.
 */
export function cn(...classes: Array<string | false | null | undefined>): string {
  return classes.filter(Boolean).join(" ");
}
