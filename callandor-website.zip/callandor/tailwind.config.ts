import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./content/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Core brand palette. Cool graphite-slate through to silver/white,
        // lifted and less saturated than pure navy for a fresher feel, with
        // a restrained teal used for highlights.
        navy: {
          DEFAULT: "#111A22",
          deep: "#0C1218",
          950: "#0C1218",
          900: "#121B24",
          800: "#1B2733",
          700: "#263644",
        },
        graphite: {
          DEFAULT: "#212E3A",
          light: "#2C3B49",
          muted: "#37485A",
        },
        silver: {
          DEFAULT: "#CDD6E0",
          bright: "#EEF3F8",
          muted: "#93A1B2",
          dim: "#657386",
        },
        teal: {
          DEFAULT: "#5AC4BF",
          bright: "#72DAD4",
          dim: "#328F8B",
          faint: "rgba(90,196,191,0.12)",
        },
      },
      fontFamily: {
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
        display: ["var(--font-display)", "Georgia", "serif"],
        wordmark: ["var(--font-wordmark)", "Georgia", "serif"],
      },
      letterSpacing: {
        wideish: "0.06em",
        wider2: "0.14em",
        widest2: "0.22em",
      },
      maxWidth: {
        content: "1200px",
        prose2: "68ch",
      },
      backgroundImage: {
        "hero-radial":
          "radial-gradient(120% 90% at 50% 0%, rgba(22,39,58,0.9) 0%, rgba(11,22,34,1) 55%, rgba(7,14,22,1) 100%)",
        "section-fade":
          "linear-gradient(180deg, rgba(7,14,22,0) 0%, rgba(11,22,34,0.6) 100%)",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(16px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "sheen": {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
        "pulse-slow": {
          "0%, 100%": { opacity: "0.35" },
          "50%": { opacity: "0.75" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.7s cubic-bezier(0.16,1,0.3,1) forwards",
        "pulse-slow": "pulse-slow 6s ease-in-out infinite",
      },
      transitionTimingFunction: {
        "out-expo": "cubic-bezier(0.16, 1, 0.3, 1)",
      },
    },
  },
  plugins: [],
};

export default config;
