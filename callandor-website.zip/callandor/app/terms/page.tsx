import type { Metadata } from "next";
import { Container } from "@/components/ui/Container";
import { company } from "@/content/site";

export const metadata: Metadata = {
  title: "Terms",
  description: `Terms of use for ${company.name}.`,
  robots: { index: false, follow: true },
};

export default function TermsPage() {
  return (
    <Container className="min-h-[70vh] py-40">
      <div className="max-w-prose2">
        <span className="eyebrow">Legal</span>
        <h1 className="display-heading mt-5 text-4xl">Terms of Use</h1>
        <p className="mt-6 leading-relaxed text-silver-muted">
          This is a placeholder. Replace with {company.name}&rsquo;s finalised
          terms of use before launch, covering acceptable use of the website,
          intellectual property, limitation of liability and governing law.
        </p>
        <p className="mt-4 text-sm text-silver-dim">
          See <span className="text-silver-muted">LAUNCH_CHECKLIST.md</span> in
          the project for the full list of content requiring approval.
        </p>
      </div>
    </Container>
  );
}
