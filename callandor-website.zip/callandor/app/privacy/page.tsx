import type { Metadata } from "next";
import { Container } from "@/components/ui/Container";
import { company } from "@/content/site";

export const metadata: Metadata = {
  title: "Privacy",
  description: `Privacy policy for ${company.name}.`,
  robots: { index: false, follow: true },
};

export default function PrivacyPage() {
  return (
    <Container className="min-h-[70vh] py-40">
      <div className="max-w-prose2">
        <span className="eyebrow">Legal</span>
        <h1 className="display-heading mt-5 text-4xl">Privacy Policy</h1>
        <p className="mt-6 leading-relaxed text-silver-muted">
          This is a placeholder. Replace with {company.name}&rsquo;s finalised
          privacy policy before launch. It should explain what personal data is
          collected via the contact form, the lawful basis for processing, how
          long data is retained, and how to make a data-subject request.
        </p>
        <p className="mt-4 text-sm text-silver-dim">
          See <span className="text-silver-muted">LAUNCH_CHECKLIST.md</span> in
          the project for the full list of content requiring approval.
        </p>
      </div>
    </Container>
  );
}
