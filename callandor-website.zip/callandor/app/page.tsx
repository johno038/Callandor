import { Hero } from "@/components/sections/Hero";
import { Evidence } from "@/components/sections/Evidence";
import { Capabilities } from "@/components/sections/Capabilities";
import { WhyCallandor } from "@/components/sections/WhyCallandor";
import { HowWeWork } from "@/components/sections/HowWeWork";
import { UseCases } from "@/components/sections/UseCases";
import { Clients } from "@/components/sections/Clients";
import { Founders } from "@/components/sections/Founders";
import { Contact } from "@/components/sections/Contact";

export default function HomePage() {
  return (
    <>
      <Hero />
      <Evidence />
      <Capabilities />
      <WhyCallandor />
      <HowWeWork />
      <UseCases />
      <Clients />
      <Founders />
      <Contact />
    </>
  );
}
