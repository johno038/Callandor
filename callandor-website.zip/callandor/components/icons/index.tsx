import { cn } from "@/lib/utils";

type IconProps = {
  className?: string;
};

const base = "h-6 w-6";

function Svg({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.25}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      className={cn(base, className)}
    >
      {children}
    </svg>
  );
}

/* ── Capability icons ─────────────────────────────────────────────── */

export function IconAssurance({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M12 3 4.5 6v5.5c0 4.5 3 7.5 7.5 9 4.5-1.5 7.5-4.5 7.5-9V6L12 3Z" />
      <path d="m8.75 12 2.25 2.25L15.5 9.75" />
    </Svg>
  );
}

export function IconApproval({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M7 3h7l4 4v10a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z" />
      <path d="M13.5 3v4H18" />
      <path d="m8.5 13 2 2 4-4.5" />
    </Svg>
  );
}

export function IconGovernance({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M12 3 4 6.5h16L12 3Z" />
      <path d="M6 10v6M10 10v6M14 10v6M18 10v6" />
      <path d="M4 19.5h16" />
    </Svg>
  );
}

export function IconTrustedAI({ className }: IconProps) {
  return (
    <Svg className={className}>
      <rect x="7.5" y="7.5" width="9" height="9" rx="1.5" />
      <path d="M10.5 11.5h3M12 10v4" />
      <path d="M9.5 3v2.5M14.5 3v2.5M9.5 18.5V21M14.5 18.5V21M3 9.5h2.5M3 14.5h2.5M18.5 9.5H21M18.5 14.5H21" />
    </Svg>
  );
}

/* ── Evidence / value icons ──────────────────────────────────────── */

export function IconIndependent({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M12 3v18" />
      <path d="M12 5 5 7l-2.5 5a3 3 0 0 0 5 0L5 7M12 5l7 2 2.5 5a3 3 0 0 1-5 0L19 7" />
      <path d="M8 21h8" />
    </Svg>
  );
}

export function IconExperience({ className }: IconProps) {
  return (
    <Svg className={className}>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7v5l3.5 2" />
    </Svg>
  );
}

export function IconCrossDomain({ className }: IconProps) {
  return (
    <Svg className={className}>
      <circle cx="7" cy="12" r="3.5" />
      <circle cx="17" cy="12" r="3.5" />
      <path d="M10.5 12h3" />
    </Svg>
  );
}

export function IconTrusted({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M12 3 5 6v6c0 4 3 6.5 7 8 4-1.5 7-4 7-8V6l-7-3Z" />
      <circle cx="12" cy="11" r="2" />
      <path d="M12 13v3" />
    </Svg>
  );
}

/* ── Process icons ───────────────────────────────────────────────── */

export function IconReview({ className }: IconProps) {
  return (
    <Svg className={className}>
      <circle cx="10.5" cy="10.5" r="6.5" />
      <path d="m15.5 15.5 4 4" />
    </Svg>
  );
}

export function IconPlan({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M4 5h16M4 12h10M4 19h13" />
      <circle cx="18.5" cy="12" r="1.4" />
      <circle cx="20.5" cy="19" r="1.4" />
    </Svg>
  );
}

export function IconDeliver({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M12 3v13" />
      <path d="m7.5 11.5 4.5 4.5 4.5-4.5" />
      <path d="M5 20h14" />
    </Svg>
  );
}

export function IconAssure({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M12 3 5 6v6c0 4 3 6.5 7 8 4-1.5 7-4 7-8V6l-7-3Z" />
      <path d="m9 12 2 2 4-4" />
    </Svg>
  );
}

export function IconEnable({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M13 3 5 13h5l-1 8 8-10h-5l1-8Z" />
    </Svg>
  );
}

/* ── Use-case icons ──────────────────────────────────────────────── */

export function IconRapid({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M13 3 5 13h5l-1 8 8-10h-5l1-8Z" />
    </Svg>
  );
}

export function IconMultiSupplier({ className }: IconProps) {
  return (
    <Svg className={className}>
      <circle cx="12" cy="5.5" r="2.5" />
      <circle cx="5.5" cy="17" r="2.5" />
      <circle cx="18.5" cy="17" r="2.5" />
      <path d="M12 8v3M10 13l-3 2M14 13l3 2" />
    </Svg>
  );
}

export function IconExercise({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M12 3v3M12 18v3M3 12h3M18 12h3" />
      <circle cx="12" cy="12" r="4.5" />
      <circle cx="12" cy="12" r="1" />
    </Svg>
  );
}

export function IconResponsibleAI({ className }: IconProps) {
  return (
    <Svg className={className}>
      <rect x="6.5" y="8.5" width="11" height="9" rx="2" />
      <path d="M12 5.5V3.5M9.5 12v2M14.5 12v2" />
      <circle cx="12" cy="5" r="1" />
    </Svg>
  );
}

/* ── Utility / interface icons ───────────────────────────────────── */

export function IconArrow({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M5 12h14M13 6l6 6-6 6" />
    </Svg>
  );
}

export function IconMail({ className }: IconProps) {
  return (
    <Svg className={className}>
      <rect x="3.5" y="5.5" width="17" height="13" rx="2" />
      <path d="m4 7 8 6 8-6" />
    </Svg>
  );
}

export function IconLinkedIn({ className }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      aria-hidden="true"
      className={cn(base, className)}
    >
      <path d="M4.98 3.5A2.5 2.5 0 1 0 5 8.5a2.5 2.5 0 0 0-.02-5ZM3 9h4v12H3V9Zm6 0h3.8v1.7h.05c.53-1 1.83-2.05 3.77-2.05C20.7 8.65 22 10.9 22 14v7h-4v-6.2c0-1.5-.03-3.4-2.08-3.4-2.08 0-2.4 1.6-2.4 3.3V21H9V9Z" />
    </svg>
  );
}

export function IconQuote({ className }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      aria-hidden="true"
      className={cn(base, className)}
    >
      <path d="M9.5 6C6.4 7 4.5 9.6 4.5 13v5h6v-6H7.6c.2-2 1.3-3.4 3-4L9.5 6Zm9 0c-3.1 1-5 3.6-5 7v5h6v-6h-2.9c.2-2 1.3-3.4 3-4L18.5 6Z" />
    </svg>
  );
}
