import { Container } from "@/components/ui/Container";
import { Wordmark } from "@/components/ui/Logo";
import { IconLinkedIn, IconMail } from "@/components/icons";
import { company, footer } from "@/content/site";

export function Footer() {
  const year = 2026; // Static to keep the build deterministic; update per calendar year.

  return (
    <footer className="relative border-t border-silver/10 bg-navy-950">
      <Container className="py-16">
        <div className="flex flex-col gap-12 md:flex-row md:items-start md:justify-between">
          <div className="max-w-sm">
            <Wordmark withTagline />
            <p className="mt-6 text-sm leading-relaxed text-silver-dim">
              Callandor helps organisations introduce complex technology safely,
              credibly and efficiently.
            </p>
          </div>

          <div className="flex flex-col gap-6 md:items-end">
            <div className="flex items-center gap-4">
              <a
                href={company.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Callandor on LinkedIn"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-silver/15 text-silver-muted transition-colors duration-300 hover:border-teal/40 hover:text-silver-bright"
              >
                <IconLinkedIn className="h-4 w-4" />
              </a>
              <a
                href={`mailto:${company.email}`}
                aria-label="Email Callandor"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-silver/15 text-silver-muted transition-colors duration-300 hover:border-teal/40 hover:text-silver-bright"
              >
                <IconMail className="h-5 w-5" />
              </a>
            </div>
            <nav
              className="flex items-center gap-6 text-sm text-silver-muted"
              aria-label="Legal"
            >
              {footer.legalLinks.map((l) => (
                <a
                  key={l.href}
                  href={l.href}
                  className="transition-colors duration-300 hover:text-silver-bright"
                >
                  {l.label}
                </a>
              ))}
            </nav>
          </div>
        </div>

        <div className="mt-14 hairline" />

        <div className="mt-8 flex flex-col gap-2 text-xs text-silver-dim sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {year} {company.name}. All rights reserved.
          </p>
          <p>
            Registered in England &amp; Wales · Company No.{" "}
            {company.companyNumber}
          </p>
        </div>
      </Container>
    </footer>
  );
}
