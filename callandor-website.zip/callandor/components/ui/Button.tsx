import Link from "next/link";
import { cn } from "@/lib/utils";

type Variant = "primary" | "ghost";

const base =
  "group inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-medium tracking-wideish transition-all duration-300 ease-out-expo focus-visible:outline focus-visible:outline-2";

const variants: Record<Variant, string> = {
  primary:
    "bg-silver-bright text-navy-950 hover:bg-white hover:shadow-[0_8px_30px_-8px_rgba(231,236,242,0.35)]",
  ghost:
    "border border-silver/25 text-silver-bright hover:border-teal/50 hover:text-white hover:bg-teal/5",
};

export function Button({
  href,
  children,
  variant = "primary",
  className,
  withArrow = false,
  ...rest
}: {
  href: string;
  children: React.ReactNode;
  variant?: Variant;
  className?: string;
  withArrow?: boolean;
} & Omit<React.ComponentProps<typeof Link>, "href">) {
  const isAnchor = href.startsWith("#") || href.startsWith("mailto:");
  const content = (
    <>
      {children}
      {withArrow && (
        <span
          aria-hidden
          className="transition-transform duration-300 ease-out-expo group-hover:translate-x-1"
        >
          →
        </span>
      )}
    </>
  );

  if (isAnchor) {
    return (
      <a href={href} className={cn(base, variants[variant], className)}>
        {content}
      </a>
    );
  }

  return (
    <Link href={href} className={cn(base, variants[variant], className)} {...rest}>
      {content}
    </Link>
  );
}
