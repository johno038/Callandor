import { cn } from "@/lib/utils";

/**
 * LogoMark — the Callandor symbol, drawn as a clean, scalable vector that
 * matches the supplied brand artwork: a slender vertical blade with a
 * four-pointed gleam at its base, flanked by two crescents forming a vesica.
 * Rendered with a brushed-silver metallic gradient.
 *
 * The gradient id is namespaced so multiple instances can coexist on a page.
 */
export function LogoMark({
  className,
  title = "Callandor",
  uid = "cal",
}: {
  className?: string;
  title?: string;
  uid?: string;
}) {
  const grad = `${uid}-blade`;
  const gradEdge = `${uid}-edge`;
  return (
    <svg
      viewBox="0 0 200 280"
      role="img"
      aria-label={title}
      className={cn("block", className)}
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <linearGradient id={grad} x1="50%" y1="0%" x2="50%" y2="100%">
          <stop offset="0%" stopColor="#F2F6FA" />
          <stop offset="35%" stopColor="#C7D0DA" />
          <stop offset="70%" stopColor="#8A97A6" />
          <stop offset="100%" stopColor="#5C6B7B" />
        </linearGradient>
        <linearGradient id={gradEdge} x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#5C6B7B" />
          <stop offset="45%" stopColor="#E6ECF2" />
          <stop offset="55%" stopColor="#E6ECF2" />
          <stop offset="100%" stopColor="#5C6B7B" />
        </linearGradient>
      </defs>

      {/* Left crescent */}
      <path
        d="M68 66 C 28 118, 28 210, 68 252 C 50 205, 50 120, 68 66 Z"
        fill={`url(#${grad})`}
      />
      {/* Right crescent */}
      <path
        d="M132 66 C 172 118, 172 210, 132 252 C 150 205, 150 120, 132 66 Z"
        fill={`url(#${grad})`}
      />

      {/* Central blade */}
      <path
        d="M100 20 C 104 90, 105 150, 100 240 C 95 150, 96 90, 100 20 Z"
        fill={`url(#${gradEdge})`}
      />

      {/* Four-pointed gleam at the base of the blade */}
      <path
        d="M100 136 L105.66 166.34 L136 172 L105.66 177.66 L100 208 L94.34 177.66 L64 172 L94.34 166.34 Z"
        fill={`url(#${grad})`}
      />
    </svg>
  );
}

/**
 * Wordmark — the CALLANDOR lettering in Trajan-style caps with a metallic fill,
 * matching the supplied logo. `withTagline` adds the ruled strapline beneath.
 */
export function Wordmark({
  className,
  withTagline = false,
}: {
  className?: string;
  withTagline?: boolean;
}) {
  return (
    <span className={cn("flex flex-col items-start leading-none", className)}>
      <span className="metal-text font-wordmark text-xl font-semibold uppercase tracking-[0.16em]">
        Callandor
      </span>
      {withTagline && (
        <span className="mt-2 text-[9px] uppercase tracking-widest2 text-silver-muted sm:text-[10px]">
          Enabling Trusted Technology
        </span>
      )}
    </span>
  );
}

/**
 * Logo — horizontal lockup (mark + wordmark). Used in the navigation bar.
 */
export function Logo({
  className,
  showWordmark = true,
  uid = "cal-full",
}: {
  className?: string;
  showWordmark?: boolean;
  uid?: string;
}) {
  return (
    <span className={cn("inline-flex items-center gap-3", className)}>
      <LogoMark className="h-9 w-auto" uid={uid} />
      {showWordmark && <Wordmark />}
    </span>
  );
}

/**
 * LogoLockup — stacked lockup (mark over wordmark over ruled tagline), echoing
 * the supplied artwork. Used in the footer and anywhere the full mark is wanted.
 */
export function LogoLockup({
  className,
  uid = "cal-lockup",
}: {
  className?: string;
  uid?: string;
}) {
  return (
    <span className={cn("inline-flex flex-col items-center gap-4", className)}>
      <LogoMark className="h-16 w-auto" uid={uid} />
      <Wordmark className="items-center [&>span:first-child]:text-2xl" withTagline />
    </span>
  );
}
