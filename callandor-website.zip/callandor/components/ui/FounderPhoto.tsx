"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";

/**
 * FounderPhoto — renders a founder's photo when present, and falls back to an
 * elegant monogram if the image is missing.
 *
 * PLACEHOLDER SYSTEM
 * Drop a square image (ideally 800×800, .jpg or .webp) at the `src` path under
 * /public/founders/ and it will appear automatically. Until then, the monogram
 * shows. No code changes required.
 */
export function FounderPhoto({
  src,
  alt,
  initials,
  className,
}: {
  src: string;
  alt: string;
  initials: string;
  className?: string;
}) {
  const [failed, setFailed] = useState(false);

  return (
    <div
      className={cn(
        "relative aspect-square w-full overflow-hidden rounded-2xl border border-silver/10 bg-graphite",
        className,
      )}
    >
      {!failed ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={src}
          alt={alt}
          onError={() => setFailed(true)}
          className="h-full w-full object-cover"
          loading="lazy"
        />
      ) : (
        <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-graphite-light to-navy-800">
          <div className="absolute inset-0 blueprint opacity-30" />
          <span className="relative font-display text-5xl font-light tracking-wide text-silver-muted">
            {initials}
          </span>
        </div>
      )}
      <div className="pointer-events-none absolute inset-0 rounded-2xl ring-1 ring-inset ring-white/5" />
    </div>
  );
}
