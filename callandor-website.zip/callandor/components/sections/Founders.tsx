import { Section, SectionHeading } from "@/components/ui/Section";
import { Reveal } from "@/components/ui/Reveal";
import { founders } from "@/content/site";

export function Founders() {
  return (
    <Section id="founders" className="bg-navy-950">
      <SectionHeading
        eyebrow={founders.eyebrow}
        title={founders.title}
        intro={founders.intro}
      />

      <div className="mt-16 grid gap-6 lg:grid-cols-2">
        {founders.people.map((person, i) => (
          <Reveal key={person.name} delay={i * 0.1}>
            <article className="surface h-full p-8 sm:p-10">
              <h3 className="font-display text-2xl font-light text-silver-bright">
                {person.name}
              </h3>
              <p className="mt-1 text-sm uppercase tracking-wider2 text-teal/80">
                {person.role}
              </p>
              <div className="mt-6 space-y-5">
                {person.bio.map((para, j) => (
                  <p
                    key={j}
                    className="text-pretty leading-relaxed text-silver-muted"
                  >
                    {para}
                  </p>
                ))}
              </div>
            </article>
          </Reveal>
        ))}
      </div>
    </Section>
  );
}
