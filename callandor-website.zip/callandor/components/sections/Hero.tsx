"use client";

import { motion, useReducedMotion } from "framer-motion";
import { Container } from "@/components/ui/Container";
import { Button } from "@/components/ui/Button";
import { hero } from "@/content/site";

const easeOut = [0.16, 1, 0.3, 1] as const;

export function Hero() {
  const reduce = useReducedMotion();

  const container = {
    hidden: {},
    visible: { transition: { staggerChildren: 0.12, delayChildren: 0.15 } },
  };
  const item = {
    hidden: { opacity: 0, y: reduce ? 0 : 24 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.9, ease: easeOut },
    },
  };

  return (
    <section
      id="top"
      className="relative flex min-h-[100svh] items-center overflow-hidden bg-hero-radial pt-24"
    >
      <HeroBackground reduce={!!reduce} />

      <Container className="relative z-10">
        <motion.div
          variants={container}
          initial="hidden"
          animate="visible"
          className="max-w-4xl"
        >
          <motion.span
            variants={item}
            className="eyebrow mb-8"
          >
            Enabling Trusted Technology
          </motion.span>

          <motion.h1
            variants={item}
            className="display-heading text-balance text-[2.6rem] leading-[1.04] sm:text-6xl lg:text-7xl"
          >
            {hero.headline}
          </motion.h1>

          <motion.p
            variants={item}
            className="mt-8 max-w-2xl text-pretty text-lg leading-relaxed text-silver-muted sm:text-xl"
          >
            {hero.supporting}
          </motion.p>

          <motion.div
            variants={item}
            className="mt-11 flex flex-col gap-4 sm:flex-row sm:items-center"
          >
            <Button href={hero.primaryCta.href} variant="primary" withArrow>
              {hero.primaryCta.label}
            </Button>
            <Button href={hero.secondaryCta.href} variant="ghost">
              {hero.secondaryCta.label}
            </Button>
          </motion.div>
        </motion.div>
      </Container>

      {/* Scroll cue */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4, duration: 1 }}
        className="absolute bottom-8 left-1/2 z-10 hidden -translate-x-1/2 sm:block"
        aria-hidden
      >
        <div className="flex flex-col items-center gap-2 text-silver-dim">
          <span className="text-[10px] uppercase tracking-widest2">Scroll</span>
          <span className="h-10 w-px bg-gradient-to-b from-silver/40 to-transparent" />
        </div>
      </motion.div>
    </section>
  );
}

/**
 * HeroBackground — abstract technical geometry inspired by the Callandor mark:
 * a large faint vesica of crescents, a blueprint grid, and slow drifting lines.
 */
function HeroBackground({ reduce }: { reduce: boolean }) {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {/* Blueprint grid, masked to fade toward the edges */}
      <div className="absolute inset-0 blueprint opacity-60 [mask-image:radial-gradient(circle_at_50%_40%,#000_0%,transparent_75%)]" />

      {/* Soft directional glow (no logo shapes) */}
      <div
        className="absolute left-1/2 top-[38%] h-[60vh] w-[60vh] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-60"
        style={{
          background:
            "radial-gradient(circle, rgba(79,182,178,0.12) 0%, rgba(22,39,58,0.10) 40%, transparent 70%)",
        }}
      />

      {/* Slow drifting scan line */}
      {!reduce && (
        <motion.div
          className="absolute inset-x-0 h-px bg-gradient-to-r from-transparent via-teal/30 to-transparent"
          initial={{ top: "20%" }}
          animate={{ top: ["20%", "80%", "20%"] }}
          transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
        />
      )}

      {/* Bottom fade into next section */}
      <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-b from-transparent to-navy-950" />
    </div>
  );
}
