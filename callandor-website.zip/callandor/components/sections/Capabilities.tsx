import { Section, SectionHeading } from "@/components/ui/Section";
import { Reveal, Stagger, StaggerItem } from "@/components/ui/Reveal";
import {
  IconAssurance,
  IconApproval,
  IconGovernance,
  IconTrustedAI,
} from "@/components/icons";
import { capabilities, expertise } from "@/content/site";

const iconMap = {
  assurance: IconAssurance,
  approval: IconApproval,
  governance: IconGovernance,
  "trusted-ai": IconTrustedAI,
} as const;

export function Capabilities() {
  return (
    <Section id="capabilities" className="relative bg-navy-800">
      <div className="absolute inset-0 bg-section-fade" aria-hidden />
      <div className="relative">
        <SectionHeading
          eyebrow={capabilities.eyebrow}
          title={capabilities.title}
          intro={capabilities.intro}
        />

        <Stagger className="mt-14 grid gap-6 sm:grid-cols-2">
          {capabilities.items.map((cap) => {
            const Icon = iconMap[cap.icon as keyof typeof iconMap];
            return (
              <StaggerItem key={cap.title}>
                <article className="surface surface-hover group h-full p-8">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-silver/15 bg-navy-950/50 text-silver-bright transition-colors duration-500 group-hover:border-teal/40 group-hover:text-teal-bright">
                    <Icon className="h-6 w-6" />
                  </div>
                  <h3 className="mt-6 font-display text-2xl font-light text-silver-bright">
                    {cap.title}
                  </h3>
                  <p className="mt-3 leading-relaxed text-silver-muted">
                    {cap.description}
                  </p>
                </article>
              </StaggerItem>
            );
          })}
        </Stagger>

        {/* Experience areas + positioning */}
        <div className="mt-8 grid gap-6 lg:grid-cols-3">
          <Reveal className="surface p-8 lg:col-span-2">
            <span className="eyebrow before:hidden">{expertise.title}</span>
            <div className="mt-6 flex flex-wrap gap-2.5">
              {expertise.areas.map((area) => (
                <span
                  key={area}
                  className="rounded-full border border-silver/15 px-4 py-2 text-sm text-silver-muted transition-colors duration-300 hover:border-teal/30 hover:text-silver-bright"
                >
                  {area}
                </span>
              ))}
            </div>
          </Reveal>

          <Reveal delay={0.1} className="surface flex flex-col justify-center p-8">
            <p className="font-display text-xl font-light leading-snug text-silver-bright">
              {expertise.positioning.lead}
            </p>
            <ul className="mt-5 space-y-2.5">
              {expertise.positioning.not.map((n) => (
                <li
                  key={n}
                  className="flex items-center gap-3 text-sm text-silver-muted"
                >
                  <span
                    aria-hidden
                    className="h-1.5 w-1.5 flex-none rounded-full bg-teal/70"
                  />
                  {n}
                </li>
              ))}
            </ul>
          </Reveal>
        </div>
      </div>
    </Section>
  );
}
