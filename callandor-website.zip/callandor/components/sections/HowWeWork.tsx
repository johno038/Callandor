"use client";

import { useRef } from "react";
import { motion, useReducedMotion, useScroll, useSpring } from "framer-motion";
import { Section, SectionHeading } from "@/components/ui/Section";
import {
  IconReview,
  IconPlan,
  IconDeliver,
  IconAssure,
  IconEnable,
} from "@/components/icons";
import { howWeWork } from "@/content/site";

const iconMap = {
  review: IconReview,
  plan: IconPlan,
  deliver: IconDeliver,
  assure: IconAssure,
  enable: IconEnable,
} as const;

const easeOut = [0.16, 1, 0.3, 1] as const;

export function HowWeWork() {
  const reduce = useReducedMotion();
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start 65%", "end 60%"],
  });
  const progress = useSpring(scrollYProgress, {
    stiffness: 80,
    damping: 24,
    restDelta: 0.001,
  });

  return (
    <Section id="how-we-work" className="relative bg-navy-800">
      <SectionHeading
        eyebrow={howWeWork.eyebrow}
        title={howWeWork.title}
        intro={howWeWork.intro}
      />

      <div ref={ref} className="relative mt-16">
        {/* Track */}
        <div className="absolute left-[19px] top-2 bottom-2 w-px bg-silver/10 lg:left-0 lg:right-0 lg:top-[27px] lg:h-px lg:w-auto lg:bottom-auto" />
        {/* Progress fill */}
        <motion.div
          className="absolute left-[19px] top-2 w-px origin-top bg-gradient-to-b from-teal to-teal/20 lg:left-0 lg:right-0 lg:top-[27px] lg:h-px lg:w-auto lg:origin-left lg:bg-gradient-to-r"
          style={
            reduce
              ? { scaleY: 1, scaleX: 1 }
              : { scaleY: progress, scaleX: progress }
          }
        />

        <ol className="grid gap-10 lg:grid-cols-5 lg:gap-6">
          {howWeWork.steps.map((step, i) => {
            const Icon = iconMap[step.icon as keyof typeof iconMap];
            return (
              <motion.li
                key={step.title}
                initial={{ opacity: 0, y: reduce ? 0 : 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.6, delay: i * 0.1, ease: easeOut }}
                className="relative flex gap-5 lg:flex-col lg:gap-0"
              >
                <div className="relative z-10 flex h-10 w-10 flex-none items-center justify-center rounded-full border border-silver/20 bg-navy-900 text-teal-bright">
                  <Icon className="h-5 w-5" />
                </div>
                <div className="lg:mt-7">
                  <div className="flex items-baseline gap-3">
                    <span className="font-display text-xs text-teal/60">
                      0{i + 1}
                    </span>
                    <h3 className="text-lg font-medium text-silver-bright">
                      {step.title}
                    </h3>
                  </div>
                  <p className="mt-2 text-sm leading-relaxed text-silver-muted">
                    {step.description}
                  </p>
                </div>
              </motion.li>
            );
          })}
        </ol>
      </div>
    </Section>
  );
}
