import { Section, SectionHeading } from "@/components/ui/Section";
import { Stagger, StaggerItem } from "@/components/ui/Reveal";
import {
  IconRapid,
  IconCrossDomain,
  IconMultiSupplier,
  IconResponsibleAI,
} from "@/components/icons";
import { useCases } from "@/content/site";

const iconMap = {
  rapid: IconRapid,
  "cross-domain": IconCrossDomain,
  "multi-supplier": IconMultiSupplier,
  "responsible-ai": IconResponsibleAI,
} as const;

export function UseCases() {
  return (
    <Section id="use-cases" className="bg-navy-950">
      <SectionHeading
        eyebrow={useCases.eyebrow}
        title={useCases.title}
        intro={useCases.intro}
      />

      <Stagger className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {useCases.items.map((item) => {
          const Icon = iconMap[item.icon as keyof typeof iconMap];
          return (
            <StaggerItem key={item.title}>
              <article className="surface surface-hover group flex h-full flex-col p-8">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-silver/15 text-silver-bright transition-colors duration-500 group-hover:border-teal/40 group-hover:text-teal-bright">
                  <Icon className="h-5 w-5" />
                </div>
                <h3 className="mt-6 text-lg font-medium text-silver-bright">
                  {item.title}
                </h3>
                <p className="mt-3 flex-1 text-sm leading-relaxed text-silver-muted">
                  {item.description}
                </p>
              </article>
            </StaggerItem>
          );
        })}
      </Stagger>
    </Section>
  );
}
