"use client";

import { useState } from "react";
import { Section, SectionHeading } from "@/components/ui/Section";
import { Reveal } from "@/components/ui/Reveal";
import { IconLinkedIn, IconMail, IconArrow } from "@/components/icons";
import { company, contact } from "@/content/site";

type Status = "idle" | "submitting" | "success" | "error";

export function Contact() {
  const [status, setStatus] = useState<Status>("idle");

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);
    const name = String(data.get("name") || "");
    const email = String(data.get("email") || "");
    const org = String(data.get("organisation") || "");
    const message = String(data.get("message") || "");

    // If a form endpoint is configured, POST to it. Otherwise fall back to a
    // pre-filled mailto so the site works with no backend.
    if (contact.formEndpoint) {
      try {
        setStatus("submitting");
        const res = await fetch(contact.formEndpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json", Accept: "application/json" },
          body: JSON.stringify({ name, email, organisation: org, message }),
        });
        setStatus(res.ok ? "success" : "error");
        if (res.ok) form.reset();
      } catch {
        setStatus("error");
      }
    } else {
      const subject = encodeURIComponent(`Enquiry from ${name || "the website"}`);
      const body = encodeURIComponent(
        `Name: ${name}\nEmail: ${email}\nOrganisation: ${org}\n\n${message}`,
      );
      window.location.href = `mailto:${company.email}?subject=${subject}&body=${body}`;
      setStatus("success");
    }
  }

  return (
    <Section id="contact" className="relative overflow-hidden bg-navy-900">
      <div className="absolute inset-0 blueprint opacity-30 [mask-image:radial-gradient(circle_at_50%_100%,#000,transparent_70%)]" />
      <div className="relative grid gap-14 lg:grid-cols-2 lg:gap-20">
        {/* Left — invitation + direct channels */}
        <div>
          <SectionHeading
            eyebrow={contact.eyebrow}
            title={contact.title}
            intro={contact.intro}
          />

          <Reveal className="mt-10 space-y-4">
            <a
              href={`mailto:${company.email}`}
              className="surface surface-hover flex items-center gap-4 p-5"
            >
              <span className="flex h-11 w-11 flex-none items-center justify-center rounded-xl border border-silver/15 text-teal-bright">
                <IconMail className="h-5 w-5" />
              </span>
              <span>
                <span className="block text-xs uppercase tracking-wider2 text-silver-dim">
                  Email
                </span>
                <span className="text-silver-bright">{company.email}</span>
              </span>
            </a>

            <a
              href={company.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="surface surface-hover flex items-center gap-4 p-5"
            >
              <span className="flex h-11 w-11 flex-none items-center justify-center rounded-xl border border-silver/15 text-teal-bright">
                <IconLinkedIn className="h-4 w-4" />
              </span>
              <span>
                <span className="block text-xs uppercase tracking-wider2 text-silver-dim">
                  LinkedIn
                </span>
                <span className="text-silver-bright">Connect with Callandor</span>
              </span>
            </a>
          </Reveal>
        </div>

        {/* Right — contact form */}
        <Reveal delay={0.1} className="surface p-8 sm:p-10">
          <form onSubmit={handleSubmit} className="space-y-5" noValidate>
            <Field label="Name" name="name" autoComplete="name" required />
            <Field
              label="Email"
              name="email"
              type="email"
              autoComplete="email"
              required
            />
            <Field
              label="Organisation"
              name="organisation"
              autoComplete="organization"
            />
            <div>
              <label
                htmlFor="message"
                className="mb-2 block text-sm text-silver-muted"
              >
                How can we help?
              </label>
              <textarea
                id="message"
                name="message"
                rows={4}
                required
                className="w-full resize-none rounded-xl border border-silver/15 bg-navy-900/60 px-4 py-3 text-silver-bright placeholder:text-silver-dim transition-colors duration-300 focus:border-teal/50 focus:outline-none"
                placeholder="Tell us a little about your programme or challenge."
              />
            </div>

            <button
              type="submit"
              disabled={status === "submitting"}
              className="group inline-flex w-full items-center justify-center gap-2 rounded-full bg-silver-bright px-6 py-3.5 text-sm font-medium text-navy-950 transition-all duration-300 ease-out-expo hover:bg-white disabled:cursor-not-allowed disabled:opacity-60"
            >
              {status === "submitting" ? "Sending…" : "Start a Conversation"}
              <IconArrow className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
            </button>

            <p
              aria-live="polite"
              className="min-h-[1.25rem] text-center text-sm"
            >
              {status === "success" && (
                <span className="text-teal-bright">
                  Thank you. Your message is on its way, we&rsquo;ll be in touch.
                </span>
              )}
              {status === "error" && (
                <span className="text-red-300">
                  Something went wrong. Please email us directly at{" "}
                  {company.email}.
                </span>
              )}
            </p>
          </form>
        </Reveal>
      </div>
    </Section>
  );
}

function Field({
  label,
  name,
  type = "text",
  required,
  autoComplete,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
  autoComplete?: string;
}) {
  return (
    <div>
      <label htmlFor={name} className="mb-2 block text-sm text-silver-muted">
        {label}
        {required && <span className="ml-1 text-teal/70">*</span>}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        required={required}
        autoComplete={autoComplete}
        className="w-full rounded-xl border border-silver/15 bg-navy-900/60 px-4 py-3 text-silver-bright placeholder:text-silver-dim transition-colors duration-300 focus:border-teal/50 focus:outline-none"
      />
    </div>
  );
}
