import { Section, SectionHeading } from "@/components/ui/Section";
import { Reveal } from "@/components/ui/Reveal";
import { clients } from "@/content/site";

export function Clients() {
  return (
    <Section id="clients" className="bg-navy-800">
      <div className="grid gap-12 lg:grid-cols-2 lg:gap-20">
        <SectionHeading
          eyebrow={clients.eyebrow}
          title={clients.title}
          intro={clients.intro}
        />

        <Reveal delay={0.1} className="flex flex-col justify-center gap-8">
          <div>
            <p className="text-xs uppercase tracking-wider2 text-teal/70">
              Primary
            </p>
            <div className="mt-4 flex flex-wrap gap-2.5">
              {clients.primary.map((c) => (
                <span
                  key={c}
                  className="rounded-full border border-silver/20 px-4 py-2 text-sm text-silver-bright"
                >
                  {c}
                </span>
              ))}
            </div>
          </div>
          <div>
            <p className="text-xs uppercase tracking-wider2 text-silver-dim">
              Secondary
            </p>
            <div className="mt-4 flex flex-wrap gap-2.5">
              {clients.secondary.map((c) => (
                <span
                  key={c}
                  className="rounded-full border border-silver/10 px-4 py-2 text-sm text-silver-muted"
                >
                  {c}
                </span>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </Section>
  );
}
