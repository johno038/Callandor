import { Section, SectionHeading } from "@/components/ui/Section";
import { Reveal, Stagger, StaggerItem } from "@/components/ui/Reveal";
import { why } from "@/content/site";

export function WhyCallandor() {
  return (
    <Section id="why" className="bg-navy-950">
      <SectionHeading
        eyebrow={why.eyebrow}
        title={why.title}
        intro={why.intro}
      />

      <Stagger className="mt-14 grid gap-px overflow-hidden rounded-2xl border border-silver/10 bg-silver/10 sm:grid-cols-2 lg:grid-cols-4">
        {why.problems.map((problem, i) => (
          <StaggerItem
            key={problem.title}
            className="group flex flex-col bg-navy-900 p-7 transition-colors duration-500 hover:bg-navy-800"
          >
            <span className="font-display text-sm text-teal/70">
              {String(i + 1).padStart(2, "0")}
            </span>
            <h3 className="mt-4 text-base font-medium text-silver-bright">
              {problem.title}
            </h3>
            <p className="mt-3 text-sm leading-relaxed text-silver-muted">
              {problem.description}
            </p>
          </StaggerItem>
        ))}
      </Stagger>

      <Reveal className="mt-10">
        <p className="max-w-3xl text-pretty font-display text-2xl font-light leading-snug text-silver-bright sm:text-[1.75rem]">
          {why.closing}
        </p>
      </Reveal>
    </Section>
  );
}
