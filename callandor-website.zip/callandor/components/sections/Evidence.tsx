import { Section, SectionHeading } from "@/components/ui/Section";
import { Reveal, Stagger, StaggerItem } from "@/components/ui/Reveal";
import { IconQuote } from "@/components/icons";
import { evidence } from "@/content/site";

export function Evidence() {
  const { testimonial, recognition } = evidence.cards;

  return (
    <Section id="evidence" className="bg-navy-950">
      <SectionHeading
        eyebrow={evidence.eyebrow}
        title={evidence.title}
        intro={evidence.intro}
      />

      {/* Evidence strip */}
      <Stagger className="mt-14 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-silver/10 bg-silver/10 lg:grid-cols-4">
        {evidence.strip.map((label) => (
          <StaggerItem
            key={label}
            className="flex items-center justify-center bg-navy-900 px-4 py-7 text-center text-xs font-medium uppercase tracking-wider2 text-silver-muted transition-colors duration-500 hover:text-silver-bright"
          >
            {label}
          </StaggerItem>
        ))}
      </Stagger>

      {/* Featured evidence cards */}
      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        {/* Card 1 — Customer testimonial */}
        <Reveal className="surface surface-hover flex flex-col p-8 sm:p-10">
          <div className="flex items-center justify-between">
            <span className="eyebrow before:hidden">{testimonial.kind}</span>
            <IconQuote className="h-8 w-8 text-teal/40" />
          </div>
          <blockquote className="mt-6 flex-1">
            <p className="text-pretty text-lg leading-relaxed text-silver-bright">
              &ldquo;{testimonial.quote}&rdquo;
            </p>
          </blockquote>
          <footer className="mt-8 border-t border-silver/10 pt-6">
            <p className="font-medium text-silver-bright">
              {testimonial.attributionName}
            </p>
            <p className="text-sm text-silver-muted">
              {testimonial.attributionOrg}
            </p>
            <p className="mt-3 text-xs italic text-silver-dim">
              {testimonial.note}
            </p>
          </footer>
        </Reveal>

        {/* Card 2 — Formal recognition */}
        <Reveal
          delay={0.1}
          className="surface surface-hover relative flex flex-col overflow-hidden p-8 sm:p-10"
        >
          <div className="absolute inset-0 blueprint opacity-40 [mask-image:radial-gradient(circle_at_80%_0%,#000,transparent_70%)]" />
          <div className="relative flex items-center justify-between">
            <span className="eyebrow before:hidden">{recognition.kind}</span>
            <IconQuote className="h-8 w-8 text-teal/40" />
          </div>
          <blockquote className="relative mt-6 flex-1">
            <p className="font-display text-2xl font-light leading-snug text-silver-bright sm:text-3xl">
              &ldquo;{recognition.quote}&rdquo;
            </p>
            {recognition.secondaryQuote && (
              <p className="mt-5 text-base leading-relaxed text-silver-muted">
                &ldquo;{recognition.secondaryQuote}&rdquo;
              </p>
            )}
          </blockquote>
          <footer className="relative mt-8 border-t border-silver/10 pt-6">
            <p className="font-medium text-silver-bright">
              {recognition.attributionName}
            </p>
            <p className="text-sm text-silver-muted">
              {recognition.attributionOrg}
            </p>
            <p className="mt-3 text-xs italic text-silver-dim">
              {recognition.caption}
            </p>
          </footer>
        </Reveal>
      </div>
    </Section>
  );
}
